#include "dispatch.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <arpa/inet.h>
#include <ctype.h>

#define MSG_SIZE sizeof(message)
#define SERVER "Server"
#define HDR_SIZE sizeof(header)

void error(char *msg)
{
    perror(msg);
    exit(EXIT_FAILURE);
}

void print_message(message *m)
{
    printf("\nMessage type %d\n", m->h.type);
    printf("Source: %s\n", m->h.source);
    printf("Dest: %s\n", m->h.dest);
    printf("Message Length is %d\n", m->h.length);
    printf("Message ID is %d\n", m->h.message_id);

    // Special print function for Client list case
    if (m->h.type == 4) {
        printf("\nData is:\n");
        for (int offset = 0; offset < m->h.length; offset++) {
            if (m->data[offset] == '\0') {
                putchar('.');
            } else {
                putchar(m->data[offset]);
            }
        }

        printf("\n");
    } 
    
    // For the regular case
    else {
        printf("\nData is:");
        for (int i = 0; i < m->h.length; i++) {
            if (isprint((unsigned char)m->data[i])) {
                putchar(m->data[i]);
            } else {
                putchar('.');
            }
        }

        printf("\n");
    }
}

message *new_message(short int type, char *src, char *dest, int length,
                     int message_id, char *data)
{
    message *m = calloc(MSG_SIZE, sizeof(char));
    assert(m != NULL);

    m->h.type = type;
    strcpy(m->h.source, src);
    strcpy(m->h.dest, dest);
    m->h.length = length;
    m->h.message_id = message_id;

    if (data != NULL) {
        memcpy(m->data, data, m->h.length);
    }

    return m;
}

void free_message(message **m)
{
    assert(m != NULL && *m != NULL);
    free(*m);
    *m = NULL;
}

void header_host_to_net(header *h)
{
    h->type = htons(h->type);
    h->length = htonl(h->length);
    h->message_id = htonl(h->message_id);
}

void header_net_to_host(header *h)
{
    h->type = ntohs(h->type);
    h->length = ntohl(h->length);
    h->message_id = ntohl(h->message_id);
}

int write_message_to_client(message *m, int fd)
{
    printf("Sending response to client\n");
    print_message(m);

    // may need to reevaluate the write size;
    int write_size = sizeof(m->h) + m->h.length;

    // Putting bytes for int fields in Network order
    header_host_to_net(&m->h);

    char buf[write_size];
    memset(buf, 0, write_size);
    memcpy(buf, &m->h, write_size);

    printf("here data is: %s\n", m->data);

    // NOTE: This cannot be blocking. If this blocks we have a big problem
    printf("Trying to write %d bytes\n", write_size);
    int n = write(fd, buf, write_size);

    if (n < 0)
        error("Error writing to socket");
    
    return n;
}

/* Class specific functions below */
Dispatch_T *new_dispatch()
{
    Dispatch_T *dispatch = malloc(sizeof(Dispatch_T));
    assert(dispatch != NULL);
    dispatch->clients = new_list();
    dispatch->table = create_table(20);
    return dispatch;
}

void free_dispatch(Dispatch_T **dispatch)
{
    assert(dispatch != NULL && *dispatch != NULL);
    free_list(&(*dispatch)->clients);
    free_table(&(*dispatch)->table);
    free(*dispatch);
    *dispatch = NULL;
}

void handle_exit(message *m, Dispatch_T *dispatch)
{
    // remove the client from the dispatch list
    remove_client(dispatch->clients, m->h.source);
}

void handle_list_request(message *m, Dispatch_T *dispatch, int fd)
{
    int size = 0;
    char *data = return_contents(dispatch->clients, &size);


    message *list_msg = new_message(4, "Server", m->h.source, size, 0, data);
    write_message_to_client(list_msg, fd);

    free_message(&list_msg);
    free(data);
}

void handle_hello(message *m, Dispatch_T *dispatch, int fd)
{
    // 1. Check if client ID already exists
    if (existing_client(dispatch->clients, m->h.source)) {
        printf("\nCLIENT EXISTS ALREADY\n");
        // If it exists, send the client an error message
        message *err_resp = new_message(7, SERVER, m->h.source, 0, 0, NULL);
        
        write_message_to_client(err_resp, fd);

        free_message(&err_resp);
        return;
    }

    // 2. If new client ID, add it to the list
    add_client(dispatch->clients, m->h.source, fd);

    // 3. Send back a hello ACK
    message *resp = new_message(2, SERVER, m->h.source, 0, 0, NULL);
    write_message_to_client(resp, fd);

    free_message(&resp);

    // 4. Send a client list message (including the client that just joined)
    handle_list_request(m, dispatch, fd);
}

void handle_chat(message *m, Dispatch_T *dispatch, int source_fd)
{
    // get the active socket associated with the destination clientID
    printf("Getting fd for %s\n", m->h.dest);
    int dest_fd = get_fd_from_clientID(dispatch->clients, m->h.dest);

    int n = 0;
    if (dest_fd >= 0) {
        // write the message to the destination socket
        n = write_message_to_client(m, dest_fd);
        if (n > 0) {
            return;
        }
    }

    // If the destination fd doesn't exist, or if chat cannot be delivered:
    // Send error message to the original client

    message *err_resp = new_message(8, SERVER, m->h.source, 0, 
        m->h.message_id, NULL);
    
    write_message_to_client(err_resp, source_fd);

    free(err_resp);
}

int parse_message(message *m, Dispatch_T *dispatch, int fd)
{
    switch (m->h.type) {
        case 1:
            // Hello from client
            printf("Server recieved hello message from fd: %d\n", fd);
            handle_hello(m, dispatch, fd);
            break;
        case 2:
            // SERVER SHOULD NOT RECEIVE THIS
            printf("Hello ack for server use only");
            // assert(false);
            break;
        case 3:
            // List request from client
            printf("Server recieved list request message\n");
            handle_list_request(m, dispatch, fd);
            break;
        case 4:
            // SERVER SHOULD NOT RECEIVE THIS
            printf("Client list for server use only");
            // assert(false);
            break;
        case 5:
            // chat
            printf("Server recieved chat message\n");\
            handle_chat(m, dispatch, fd);
            break;
        case 6:
            // exit
            printf("Server recieved exit message\n");
            handle_exit(m, dispatch);
            return -1;
        case 7:
            // SERVER SHOULD NOT RECEIVE THIS
            printf("Client present error for server use only");
            // assert(false);
            break;
        case 8:
            // SERVER SHOULD NOT RECEIVE THIS
            printf("Cannot deliver for server use only");
            // assert(false);
            break;
        default:
            // SERVER SHOULD NOT RECEIVE THIS
            printf("Message type not recognized %d\n", m->h.type);
            break;
    }

    return 0;

}

header* read_partial_header(int fd, char *buf, int size_pending, 
    Dispatch_T *dispatch)
{
    // Read the header first
    char head_buf[HDR_SIZE];
    memset(head_buf, 0, HDR_SIZE);

    memcpy(head_buf, buf, size_pending);

    int nbytes = read(fd, head_buf + size_pending, HDR_SIZE - size_pending);
    nbytes += size_pending;

    if (nbytes < 0)
    {
        error("Read error");
    }
    else if (nbytes == 0)
    {
        printf("Reached EOF while reading header\n");
        return 0;
    }

    // If we failed to read in the complete header
    if (nbytes < HDR_SIZE)
    {
        // store the message in the hash table for future reading
        char *msg = calloc(nbytes, sizeof(char));
        assert(msg != NULL);

        memcpy(msg, head_buf, nbytes);
        Entry_H *entry = create_entry(fd, msg, nbytes);
        add_entry_to_table(dispatch->table, entry);
    }

    header *h = calloc(HDR_SIZE, sizeof(char));
    assert(h != NULL);
    memcpy(h, head_buf, HDR_SIZE);

    // Convert the header from network byte order to host byte order
    header_net_to_host(h);

    return h;
}

header* read_header(int fd, Dispatch_T *dispatch, int size_pending)
{
    // Read the header first
    char head_buf[HDR_SIZE];
    memset(head_buf, 0, HDR_SIZE);



    int nbytes = read(fd, head_buf, HDR_SIZE);
    if (nbytes < 0)
    {
        error("Read error");
    }
    else if (nbytes == 0)
    {
        printf("Reached EOF while reading header\n");
        return 0;
    }

    // If we failed to read in the complete header
    if (nbytes < HDR_SIZE)
    {
        // store the message in the hash table for future reading
        char *msg = calloc(nbytes, sizeof(char));
        assert(msg != NULL);

        memcpy(msg, head_buf, nbytes);
        Entry_H *entry = create_entry(fd, msg, nbytes);
        add_entry_to_table(dispatch->table, entry);
    }

    header *h = calloc(HDR_SIZE, sizeof(char));
    assert(h != NULL);
    memcpy(h, head_buf, HDR_SIZE);

    // Convert the header from network byte order to host byte order
    header_net_to_host(h);

    return h;
}

char* get_pending_bytes(int fd, int *size_pending, Dispatch_T *dispatch)
{
    Entry_H *entry = get_entry_from_table(dispatch->table, fd);
    if (entry == NULL) {
        printf("No pending bytes\n");
        *size_pending = 0;
        return NULL;
    }

    printf("pending bytes\n");

    *size_pending = entry->len;
    return entry->buffer;
}

int read_message(int fd, Dispatch_T *dispatch)
{
    // Check and see if there are any pending bytes in the hash table
    int size_pending = 0;
    char *pending_bytes = get_pending_bytes(fd, &size_pending, dispatch);
    if (size_pending != 0) {
        if (size_pending < 50) {
            printf("header missing\n");
        } 
        
        else if (size_pending >= 50) {
            // header complete, message hasn't been read fully
            // retrieve from buffer
            printf("message missing\n");
        }
    }

    int nbytes = 0;
    header *h;

    // Keeping these two cases seperate for my sanity
    if (size_pending == 0) {
        h = read_header(fd, dispatch, size_pending);
        if (h == NULL) {
            return 0;
        }
        
    } else if (size_pending < 50) {
        // header hasn't been read in yet fully
        h = read_partial_header(fd, pending_bytes, size_pending, dispatch);
        if (h == NULL) {
            return 0;
        }
        // retrieve from buffer
    } else if (size_pending >= 50) {

        // message will have to be read in specially
    }


    // Allocate memory for message
    message *m = calloc(MSG_SIZE, sizeof(char));
    assert(m != NULL);

    // Copy the header into the message
    memcpy(&m->h, h, HDR_SIZE);
    free(h);

    // If the message has data, read it
    if (m->h.length > 0)
    {
        nbytes = read(fd, m->data, m->h.length);
        if (nbytes < 0) {
            free(m);
            error("Read error");
        }
        else if (nbytes == 0) {
            printf("Reached EOF\n");
            // buffer the header 

            return 0;
        }

        else if (nbytes < (m->h.length - 1)) {
            // buffer the header

        }
    }

    // If we have a complete message, parse it:
    int n = parse_message(m, dispatch, fd);

    free_message(&m);

    return n;
}