#include "list.h"
#include <assert.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>

#define BUFSIZE 400
#define IDSIZE 20


Entry_T* new_entry(char *clientID, int fd)
{
    Entry_T *e = malloc(sizeof(Entry_T));
    assert(e != NULL);

    char *buf = calloc(IDSIZE, sizeof(char));
    assert(buf != NULL);

    strcpy(buf, clientID);
    e->clientID = buf;
    e->fd = fd;
    return e;
}

void free_entry(Entry_T **entry)
{
    assert(entry != NULL);
    assert(*entry != NULL);

    free((*entry)->clientID);
    (*entry)->clientID = NULL;

    free(*entry);
    *entry = NULL;
}

List_T* new_list()
{
    List_T *list = malloc(sizeof(List_T));
    assert(list != NULL);

    list->capacity = 20;
    list->size = 0;
    list->e = calloc(sizeof(Entry_T*), list->capacity);

    return list;
}

void free_list(List_T **list)
{
    // Do not allow free_list to be misused
    assert(list != NULL);
    assert(*list != NULL);

    // Free every entry in the list
    for (int i = 0; i < (*list)->size; i++) {
        free_entry(&(*list)->e[i]);
    }

    free((*list)->e);
    free(*list);
    *list = NULL;
}

void expand(List_T *list)
{
    (void)list;
    return;
}

void add_client(List_T *list, char *clientID, int fd)
{
    // If the list is full, expand
    if (list->size == list->capacity) {
        // expand(list);
    }

    list->e[list->size] = new_entry(clientID, fd);
    list->size++;
}

void remove_client(List_T *list, char *clientID)
{
    if (list->size == 0) {
        //nothing to remove
        return;
    }

    // first, find client
    for (int i = 0; i < list->size; i++) {
        if (strcmp(list->e[i]->clientID, clientID) == 0) {
            
            // Remove from list
            free_entry(&list->e[i]);
            list->size--;

            // Shift over elements
            for (int j = i; i < list->size; j++) {
                list->e[j] = list->e[j + 1];
            }

            // We are only removing the first element with that client id
            break;
        }
    }
}

bool existing_client(List_T *list, char *clientID)
{
    for (int i = 0; i < list->size; i++) {
        if (strcmp(list->e[i]->clientID, clientID) == 0) {
            return true;
        }
    }

    return false;
}

int get_fd_from_clientID(List_T *list, char *clientID)
{
    for (int i = 0; i < list->size; i++) {
        if (strcmp(list->e[i]->clientID, clientID) == 0) {
            return list->e[i]->fd;
        }
    }

    // could not find fd associated with clientID
    return -1;
}

void print_buffer_content(char *buf, int offset)
{
    printf("Buffer content: ");
    for (int i = 0; i < offset; i++)
    {
        if (buf[i] == '\0')
            printf(".");
        else
            printf("%c", buf[i]);
    }
    printf("\n");
}

char *return_contents(List_T *list, int *size)
{
    // Initializing buffer size to 400
    char *buf = calloc(BUFSIZE, sizeof(char));
    assert(buf != NULL);

    int offset = 0;

    for (int i = 0; i < list->size; i++)
    {
        int len = strlen(list->e[i]->clientID);
        if (offset + len + 1 >= BUFSIZE)
        {
            fprintf(stderr, "Client list contents too long\n");
            assert(false);  // spec says not to worry about this case
        }

        // Copy client ID into buffer
        memcpy(buf + offset, list->e[i]->clientID, len);
        offset += len;

        // Add a null-terminator after each client ID
        buf[offset] = '\0';
        offset++;
    }

    print_buffer_content(buf, offset);

    *size = offset;
    return buf;
}