// using structs to represent the list under the hood
// these provide flexibility for changing the implementation without changing
// the interface
#include <stdbool.h>

// this shouldn't have to go in the interface, but whatever
typedef struct {
    char *clientID;
    int fd;
} Entry_T;

typedef struct {
    Entry_T **e;
    unsigned size;
    unsigned capacity;
} List_T;

List_T* new_list();

void free_list(List_T **list);

// add new client to back of list
void add_client(List_T *list, char *clientID, int fd);

// remove client from list
void remove_client(List_T *list, char *clientID);

// see if client exists
bool existing_client(List_T *list, char *clientID);

// get the socket fd from the clientID
int get_fd_from_clientID(List_T *list, char *clientID);

// return all the connect clients as a comma separated string
char *return_contents(List_T *list, int *size);